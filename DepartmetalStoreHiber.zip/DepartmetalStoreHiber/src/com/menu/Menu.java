package com.menu;

import java.util.*;

import com.dao.UserValidation;
import com.service.UserService;

public class Menu {
private Scanner sc;
UserService user;
public Menu(){
	sc=new Scanner(System.in);
	user=new UserService();
}
public void  showDeatils() {
	
	int ch=0;
	String choice="y";
	while(choice.equals("y")){
		System.out.println("enter your choice");
		System.out.println("1.login as admin");
		System.out.println("2.login as user");
		System.out.println("3.register");
		ch=sc.nextInt();
		switch(ch) {
		case 1:
			System.out.println("****Welcome to Admin Page****");
			user.adminAuthetication();

			break;	
		case 2:
			System.out.println("***Welcome to Customer Page***");
			user.userAuthetication();
			break;
		case 3:
			user.registerUser();
			break;
		}
		System.out.println("Do you want to continue Y/N");
		choice=sc.next();
}
}
}
