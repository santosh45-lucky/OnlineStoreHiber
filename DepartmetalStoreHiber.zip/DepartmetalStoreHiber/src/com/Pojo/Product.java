package com.Pojo;
import java.util.*;
public class Product extends Item{
	private int productId;
	private String productName;
	private int sellingprice;
	private int availabalequatity;
	User uobj;
	public User getUobj() {
		return uobj;
	}
	public void setUobj(User uobj) {
		this.uobj = uobj;
	}
	public int getProductId() {
		return productId;
	}
	public int setProductId(int productId) {
		return this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getSellingprice() {
		return sellingprice;
	}
	public void setSellingprice(int sellingprice) {
		this.sellingprice = (int) (getBuyingprice()+ (getBuyingprice()*0.5));
	}
	public int getAvailabalequatity() {
		return availabalequatity;
	}
	public void setAvailabalequatity(int availabalequatity) {
		this.availabalequatity = availabalequatity;
	}
}
