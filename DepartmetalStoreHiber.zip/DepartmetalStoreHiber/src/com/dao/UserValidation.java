package com.dao;

import org.hibernate.*;

import java.sql.SQLException;
import java.util.*;

import com.Pojo.User;

import com.sessionfactory.Connect;

public class UserValidation {
	StoreInfo sinfo;
	SessionFactory sesfact;
	Session session;
	Transaction tx;
	Scanner sc;
public UserValidation(){
	sc=new Scanner(System.in);
	sesfact=Connect.getConnect();
	sinfo=new StoreInfo();
}
public void adminCheck() {
	session=sesfact.openSession();
	tx=session.beginTransaction();
	System.out.println("enter userid");
	int uid=sc.nextInt();
	System.out.println("enter password");
	String upass=sc.next();
	//System.out.println("eneter user type");
	//String type=sc.next();
	//User uob=session.find(User.class, id);
	//it will match the userid and password
	org.hibernate.query.Query q=session.createQuery("select u from User u where u.userid=:id and u.password=:pass");
	q.setParameter("id", uid);
	q.setParameter("pass", upass);
	List<User>  ulist=q.list();
	//System.out.println("list is "+ulist);
	if(!ulist.isEmpty()) 
	{
		for(User u:ulist)
		{
			String utype=u.getType();
			
			if(utype.equals("admin"))
			{
				System.out.println("Admin login");
				//adminAuthentication() ;
				int ch=0;
				String choice="y";
				while(choice.equals("y")){
					System.out.println("Enter your choice...");
					System.out.println("1.Insert into Store");
					System.out.println("2.Serach product ById");
					System.out.println("3.Display by category");
					System.out.println("4.Calculate total amount");
					System.out.println("5.Search Product ByName");
					System.out.println("6.Calculate profit amount");
					System.out.println("7.exit");
					
					ch=sc.nextInt();
					switch(ch) {
					case 1:
						System.out.println("insert the item");
				sinfo.insertProduct(u);
						break;
			
					case 2:
						sinfo.searchById();
						break;
					case 3:
						sinfo.listByCategory();
						break;
					case 4:
						sinfo.Total();
						break;
						case 5:
						sinfo.searchByName();
							break;
						case 6:	
							sinfo.findProfit();
							break;
						case 7:
				//	System.exit(0);
					
					
					}
					System.out.println("Do you want to continue Y/N");
					choice=sc.next();
				}

				break;
			}
			else if(utype.equals("user"))
			{	
				System.out.println("user login");
				//userAuthentication();
				int ch=0;
				String choice="y";
				while(choice.equals("y")){
					System.out.println("Enter your choice....");
					System.out.println("1.Login and view product");
					System.out.println("2.Register");
					System.out.println("3.Provide supercoins");
					System.out.println("4.Filter by category and price");
					System.out.println("5.Buy product by name or id");
					System.out.println("6.Add product to Cart");
					System.out.println("7.Generate Final Bill");
					System.out.println("8.exit");
					ch=sc.nextInt();
					switch(ch) {
					case 1:
						sinfo.UserView();
						break;
					case 2:
						userRegistration();
						break;
					case 3:
						System.out.println("you get 100 spercoins");
						break;
					case 4:
					
						break;
					case 5:
						sinfo.buyProduct(u);
						break;
					case 6:
						//sinfo.addProduct(u);
						break;
					case 7:
						//sinfo.billGenerate();
						break;
					case 8:
						System.exit(0);
						break;
						}
					System.out.println("do you want to contiinue y/n");
					choice=sc.next();
				}
				break;
			}
		}
		}
	else
	{
		System.out.println("ooiinvalid user ");
	}
	}

public void userCheck() {
	session=sesfact.openSession();
	tx=session.beginTransaction();
	System.out.println("enter userid ");
	int uid=sc.nextInt();
	System.out.println("enter password");
	String upass=sc.next();
	Query q=session.createQuery("select u from User u where u.userid=:id and u.password=:pass");
	q.setParameter("id",uid);
	q.setParameter("pass",upass);
	List<User> ulist=q.getResultList();
	if(ulist!=null) {
		System.out.println("loginn sucessfully");
		userAuthentication();
	}else {
		System.out.println("invalid user");
	}
}
public void userRegistration() {
	session=sesfact.openSession();
	tx=session.beginTransaction();
	System.out.println("***Welcome To my portal***");
	System.out.println("please enter below deatils ");
	System.out.println("enter howmany user you want to insert");
	int n=sc.nextInt();
	for(int i=0;i<n;i++) {
		User u=new User();
		System.out.println("enter user id");
		u.setUserid(sc.nextInt());
		System.out.println("enter user name");
		u.setUsername(sc.next());
		System.out.println("enter Emailid");
		u.setEmail(sc.next());
		System.out.println("enter password");
		u.setPassword(sc.next());
		System.out.println("enter user usertype");
		u.setType(sc.next());
		u.setSupercoin(100);
		session.save(u);
	}
	tx.commit();
}

public void userAuthentication(){
	
	}
}
