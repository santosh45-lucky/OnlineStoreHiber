package com.service;

import com.dao.UserValidation;

public class UserService {
UserValidation uservice;
public UserService(){
	uservice=new UserValidation();
}
public void adminAuthetication() {
	uservice.adminCheck();
}
public void userAuthetication() {
	uservice.userCheck();
}
public void registerUser() {
	uservice.userRegistration();
}
}
