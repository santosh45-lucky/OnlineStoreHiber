package com.sessionfactory;
import java.util.*;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;
public class Connect {
private static SessionFactory sesfact;
private Session session;
private Transaction tx;
Connect(){
	sesfact=new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
	System.out.println("connected");
}
public static SessionFactory getConnect() {
	
	Connect con=new Connect();
	
	return sesfact;
}
public static void main(String args[]) {
	getConnect();
}
}
