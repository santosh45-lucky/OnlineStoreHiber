package com.Pojo;

public class Item {
	private int itemcode;
private  String itemname;
private String category;
private int buyingprice;
public String getItemname() {
	return itemname;
}
public void setItemname(String itemname) {
	this.itemname = itemname;
}
public String getCategory() {
	return category;
}
public int getItemcode() {
	return itemcode;
}
public void setItemcode(int itemcode) {
	this.itemcode = itemcode;
}
public void setCategory(String category) {
	this.category = category;
}
public int getBuyingprice() {
	return buyingprice;
}
public void setBuyingprice(int buyingprice) {
	this.buyingprice = buyingprice;
}
}
