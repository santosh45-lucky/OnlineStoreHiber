package com.dao;
import java.util.*;
import org.hibernate.*;

import com.Pojo.Item;
import com.Pojo.Product;
import com.Pojo.User;
import com.sessionfactory.Connect;
public class StoreInfo {
Scanner sc;
SessionFactory sesfact;
Session session;
Transaction tx;
List<Product> buyinglist;
public StoreInfo(){
	sc=new Scanner(System.in);
	sesfact=Connect.getConnect();
	buyinglist=new ArrayList<>();
}
public void insertProduct(User u) {
	//User u=new User();
	Set<Product> plist=new HashSet<>();
	session=sesfact.openSession();
	tx=session.beginTransaction();
	System.out.println("enter howmany item you want to insert");
	int n=sc.nextInt();
	for(int i=0;i<n;i++) {
		Product iobj=new Product();
		System.out.println("enter item code");
		iobj.setItemcode(sc.nextInt());
		System.out.println("enter item name");	
		iobj.setItemname(sc.next());
		System.out.println("enter item category");
		iobj.setCategory(sc.next());
		System.out.println("enter Buying price");
		int price=sc.nextInt();
		iobj.setBuyingprice(price);
		iobj.setSellingprice(price);
		System.out.println("enter avaibable quntity");
		iobj.setAvailabalequatity(sc.nextInt());
		System.out.println("enter product name");
		iobj.setProductName(sc.next());
		System.out.println("enter product id");
		iobj.setProductId(sc.nextInt());
		//System.out.println("enter item code");
		plist.add(iobj);
		u.setPlist(plist);
		iobj.setUobj(u);
		session.save(iobj);
	}
	tx.commit();
//System.out.println("enter howmany product you want to  insert");
}
public void searchById() {
	session=sesfact.openSession();
	tx=session.beginTransaction();
	System.out.println("enter producct id");
	int id=sc.nextInt();
	Query q=session.createQuery("select p from Product where p.productname=:pname");
	List<Product> clist=q.list();
	for(Product pobj:clist) {
		System.out.println("product name:"+pobj.getProductName());
		System.out.println("product name:"+pobj.getSellingprice());
		System.out.println("product name:"+pobj.getAvailabalequatity());
		
	}
}
public void listByCategory() {
	session=sesfact.openSession();
	tx=session.beginTransaction();
	System.out.println("enter category");
	String cat=sc.next();
	Query q=session.createQuery("select p from Item p where p.category=:c");
	q.setParameter("c", cat);
	List<Item> plist=q.list();
	for(Item p:plist) {
		System.out.println("aviavle product");
		System.out.println(p.getItemname());
	}
}
public void searchByName() {
	session=sesfact.openSession();
	tx=session.beginTransaction();
	System.out.println("enter producct name");
	String name=sc.next();
	//Product pobj=session.find(Product.class, name);
	Query q=session.createQuery("select p from Product p where p.productName=:pname");
	q.setParameter("pname", name);
	List<Product> plist=q.list();
	for(Product pobj:plist) {
		System.out.println("product name:"+pobj.getProductName());
		System.out.println("product name:"+pobj.getSellingprice());
		System.out.println("product name:"+pobj.getAvailabalequatity());
		
	}
}
public void Total() {
	session=sesfact.openSession();
	tx=session.beginTransaction();
	int total = 0;
	Query q=session.createQuery("from Product");
	//using aggrete funtion
	///Query q=session.createQuery("select sum(p.sellingprice) from Product p");
	List<Product> ilist=q.list();
	for(Product i:ilist) {
		total=total+i.getSellingprice();
	}
	System.out.println("Total amount"+total);
}
public void findProfit() {
	session=sesfact.openSession();
	tx=session.beginTransaction();
	int profit=0;
	int btotal=0;
	int stotal=0;		

	Query q=session.createQuery("from Product");
	List<Product> ilist=q.list();
	for(Product p:ilist) {
		btotal=btotal+p.getBuyingprice();
		stotal=stotal+p.getSellingprice();
	}
	profit=stotal-btotal;
	System.out.println("Profit is"+profit);
	
}
public void UserView(){
	session=sesfact.openSession();
	tx=session.beginTransaction();
	Query q=session.createQuery("from Product");
	List<Product> ilist=q.list();
	for(Product p:ilist) {
		System.out.println("productname"+p.getProductName());
		System.out.println("product id"+p.getProductId());
		
	}
}
public void buyProduct(User u) {
	session=sesfact.openSession();
	tx=session.beginTransaction();
	System.out.println("avaibale product");
	Query q=session.createQuery("from Product");
	List<Product> alist=q.list();
	for(Product p:alist) {
		System.out.println("product id"+p.getProductId());
		System.out.println("product name"+p.getProductName());
		System.out.println("avaiable product"+p.getAvailabalequatity());
	}
	String choice="y";
	while(choice.equals("y")) {
	Product p=new Product();
	System.out.println("enter the product id which you want to buy");
	int id=sc.nextInt();
	Query q1=session.createQuery("select p from Product p where productId=:pid");
	q1.setParameter("pid", id);
	List<Product> clist=q1.list();
	for(Product pp:clist) {
		pp.getProductName();
		pp.getSellingprice();
	
	buyinglist.add(pp);
	}
	System.out.println("do you want to continue");
	choice=sc.next();
	}
	System.out.println("added sucessfulyy");
//	System.out.println();
	billGenerate();
}
/*
public void addProduct(User u) {
	session=sesfact.openSession();
	tx=session.beginTransaction();
	System.out.println("avaibale product");
	Query q=session.createQuery("from Product");
	List<Product> alist=q.list();
	for(Product p:alist) {
		System.out.println("product name"+p.getProductName());
		System.out.println("avaiable product"+p.getAvailabalequatity());
	}
	System.out.println("enter howmany product you want to buy");
	int n=sc.nextInt();
	for(int i=0;i<n;i++) {
		Product p=new Product();
		System.out.println("enter pid");
		int id=sc.nextInt();
		Query q1=session.createQuery("select p from Product p where p.productId=:pid");
		q1.setParameter("pid", id);
		List<Product> plist=q1.list();
        if(!plist.isEmpty()) {
		buyinglist.add(p);
	}
	}
	System.out.println(buyinglist);
	System.out.println("**PRODUCT added to cart**");
	System.out.println("produtc aare");
	for( Product p:buyinglist) {
		System.out.println(p.getProductName());
	}
	billGenerate(buyinglist);
}*/

public void billGenerate() {
	//System.out.println("");
	int total=0;
	for(Product p:buyinglist) {
		total=total+p.getSellingprice();
	}
	System.out.println("Total money you spend"+total);
	System.out.println("Thank you for Shopping");
}
public void fillterByprice() {
	//session=sesfact.
}
}